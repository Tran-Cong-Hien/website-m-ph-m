# ba-i-th-c-t-p-chuy-n-m-n
# THỰC TẬP CHUYÊN MÔN NĂM HỌC 2019-2020
Họ tên:Trần Công Hiền
Mã sinh viên:5851071022
Lớp:Công nghệ thông tin k58
## Đề tài: WEBSITE BÁN MỸ PHẨM
## Phần 1: Công nghệ sử dụng
- SQL SERVER 2018
-ASP.NET MVC
-VISUAL STUDIO 2017

## Phần 2: Các chức năng đã hoàn thành
1. Hiển thị các sản phẩm theo yêu cầu trên trang chủ
2. Hiển thị chi tiết sản phẩm khi link vào
3.hiển thị sản phẩm theo danh mục
4.Hiển thị Tin tức theo danh mục
5.Hiển thị chi tiết tin tức
6. Xây dựng Giỏ hàng .
7.Đưa sản phẩm vào giỏ hàng 
8.Hiện thị ra số sản phẩm số lượng sản phẩm khách đã mua(tạm thời) trong giỏ hàng
9.Thanh Toán Đơn trong giỏ hàng (tính ra được số tiền trong giỏ hàng khách yêu cầu) và hiện ra Đơn hàng bao gồm(thông tin khách hàng số tiên tổng khi thanh toán) khi khách thanh toán tiền
10.Phân quyên Admin , khách hàng, Nhân viên như sau:
- phân quyền khách hàng chỉ xem được trên trang hiển thị (trang chủ , tin tức , sản phẩm,..vv)
-phân quyên Admin : truy xuất vào được vùng Admin (trang admin : thông tin sản phẩm , tin tức ,danh mục   với cách chức năng thêm sửa xóa sản phẩm)
-phân quyên Nhân viên :vào được vùng Admin (được quyền thêm sửa xóa ở các trang danh mục ,tin tức,sản phẩm,) không dược quyền xem thông tin khách hàng ,chi tiết đơn hàng cũng như doanh thu.
11. Hiển thị chi tiết sản phẩm khi link vào sản phẩm (nút mua hàng,thông tin sản phẩm)
12.phân loại sản phẩm theo danh mục riêng
13.Hiển thị mobile (ip5,6.7,8 ,ipad pro)
14.xây dựng thành công Form đăng nhập ,Form đăng kí (đăng nhập dăng kí được)
15.Mã hóa mật khẩu theo MD5 MVC

...
## Phần 3: Các chức năng chưa hoàn thành
1. không thêm được thông tin hình ảnh của sản phẩm trong giỏ hàng

2. Chua thêm xóa sửa ở trang admin (tin tức)

## Hướng dẫn sử dụng
Bước 1: Vào link Website là có thể xem được sản phẩm ,tin tức nhưng không mua được hàng
Bước 2: Đăng nhập để mua hàng. Nếu không có tài khoản thì đăng kí tài  khoản
Bước 3 : Bạn có thể xem và mua sản phẩm , sẽ được lưu lại ở giỏ hàng và bạn vào giỏ hàng nhập thông tin để thanh toán . Thanh toán thành công sẽ xuất thông tin giao nhận của ban.
Bước 4 : với Admin phải đăng nhập tài khoản Admin mới có quyên truy cập vào trang Admin thì thêm link sau: /Admin/DashBoar/Index 

Xin cám ơn!
